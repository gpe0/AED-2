var searchData=
[
  ['trip_0',['Trip',['../class_trip.html',1,'Trip'],['../class_trip.html#aa67b77d0d2de622ed5eb9e9cad34db8f',1,'Trip::Trip()'],['../class_trip.html#a0e5d39accd86512f53caa5fd3d5903e0',1,'Trip::Trip(std::list&lt; Stop &gt; stopsPath, std::list&lt; Line &gt; linesPath, double distance, int difZones)']]]
];
