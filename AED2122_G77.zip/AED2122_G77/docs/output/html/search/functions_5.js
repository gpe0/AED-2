var searchData=
[
  ['line_0',['Line',['../class_line.html#acc11b8a429d8cdd63ba6803dff5602b3',1,'Line::Line()'],['../class_line.html#aa7b1b2ac05c5a9405d93b9ebfa85272a',1,'Line::Line(std::string code, std::string name)']]]
];
