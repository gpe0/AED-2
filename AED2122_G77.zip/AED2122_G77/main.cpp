#include <iostream>
#include "Code/Interface.h"

using namespace std;

int main() {
    cout << "AED 2021/2022 - Projeto 2" << endl;

    Interface::menu();

    return 0;
}
